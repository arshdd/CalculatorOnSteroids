using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace CALCULATOR_ON_STEROIDS_PROGRAM
{
    public partial class frmCalculator : Form
    {
        string btnSel = "";
        bool isBtnSel = false;
        double val = 0;
        decimal MemoryStore = 0;

        public frmCalculator()
        {
            InitializeComponent();
        }

        private void ButtonKeyPress(object sender, KeyPressEventArgs e)
        { 
            switch(e.KeyChar.ToString()) 
            {
                case "0":
                    btnZero.PerformClick();
                    break;
                case "1":
                    btnOne.PerformClick();
                    break;
                case "2":
                    btnTwo.PerformClick();
                    break;
                case "3":
                    btnThree.PerformClick();
                    break;
                case "4":
                    btnFour.PerformClick();
                    break;
                case "5":
                    btnFive.PerformClick();
                    break;
                case "6":
                    btnSix.PerformClick();
                    break;
                case "7":
                    btnSeven.PerformClick();
                    break;
                case "8":
                    btnEight.PerformClick();
                    break;
                case "9":
                    btnNine.PerformClick();
                    break;
                case "+":
                    btnPlus.PerformClick();
                    break;
                case "-":
                    btnMinus.PerformClick();
                    break;
                case "*":
                    btnMultiply.PerformClick();
                    break;
                case "/":
                    btnDivide.PerformClick();
                    break;
                case ".":
                    btnDecimal.PerformClick();
                    break;
                case "%":
                    btnPercent.PerformClick();
                    break;
                case "=":
                    btnEqual.PerformClick();
                    break;
                case "ENTER":
                    btnEqual.PerformClick();
                    break;
                case "BACKSPACE":
                    btnBackspace.PerformClick();
                    break;
                default:
                    break;
            }          
        }
        private void buttonNumber_Click(object sender, EventArgs e)
        {
            if ((txtEquation.Text == "0") || (isBtnSel))
                txtEquation.Clear();

            isBtnSel = false;
            Button btnPressSel = (Button)sender;
            if (btnPressSel.Text == ".") 
            {
                if (!(txtEquation.Text.Contains(".")))
                {
                    txtEquation.Text = txtEquation.Text + btnPressSel.Text;
                }      
            }
            else
            {
                txtEquation.Text = txtEquation.Text + btnPressSel.Text;
            }
        }
        private void buttonOperation_Click(object sender, EventArgs e)
        {
            Button btnPressSel = (Button)sender;

            //Add to History
            if (btnPressSel.Text == "+")
            {
                AddToHistory("Add", txtEquation.Text);
            }
            else if (btnPressSel.Text == "-")
            {
                AddToHistory("Minus", txtEquation.Text);
            }
            else if (btnPressSel.Text == "*")
            {
                AddToHistory("Multiply", txtEquation.Text);
            }
            else if (btnPressSel.Text == "/")
            {
                AddToHistory("Divide", txtEquation.Text);
            }

            if (val != 0)
            {
                btnEqual.PerformClick();
                isBtnSel= true;
                btnSel = btnPressSel.Text;
                lblEquation.Text = $"{val} {btnSel}";
            }
            else
            {
                val = Double.Parse(txtEquation.Text);
                isBtnSel = true;
                btnSel = btnPressSel.Text;
                lblEquation.Text = $"{val} {btnSel}";               
            }
        }
        private void buttonCE_Click(object sender, EventArgs e) 
        {
            txtEquation.Text = "0";
            lblEquation.Text = "";
        }
        public void buttonEqual_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();

            lblEquation.Text = "";
            switch (btnSel) 
            {
                case "+":
                    txtEquation.Text = (val + Double.Parse(txtEquation.Text)).ToString();

                    //Add to History
                    AddToHistory("Equal", txtEquation.Text);

                    break;
                case "-":
                    txtEquation.Text = (val - Double.Parse(txtEquation.Text)).ToString();

                    //Add to History
                    AddToHistory("Equal", txtEquation.Text);

                    break;
                case "*":
                    txtEquation.Text = (val * Double.Parse(txtEquation.Text)).ToString();

                    //Add to History
                    AddToHistory("Equal", txtEquation.Text);

                    break;
                case "/":
                    txtEquation.Text = (val / Double.Parse(txtEquation.Text)).ToString();

                    //Add to History
                    AddToHistory("Equal", txtEquation.Text);

                    break;
                default:

                    //Add to History
                    AddToHistory("Equal", txtEquation.Text);

                    break;
            }

            val = double.Parse(txtEquation.Text);
            btnSel = "";

        }
        private void buttonClear_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();

            txtEquation.Text = "0";
            val = 0;
            lblEquation.Text = "";

            //Add to History
            AddToHistory("Clear", txtEquation.Text);
        }
        private void buttonBackspace_Click(object sender, EventArgs e)
        {
            if ((string.Compare(txtEquation.Text, " ") < 0))
            {
                txtEquation.Text = txtEquation.Text.Substring(0, txtEquation.Text.Length - 1 + 1);
            }
            else 
            {
                txtEquation.Text = txtEquation.Text.Substring(0, txtEquation.Text.Length - 1);
            }
        }
        private void digitCalculate_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();

            Button btnPressSel = (Button)sender;
            string btnPressName = btnPressSel.Text;

            //Memory Clear
            if (btnPressName == "MC")
            {
                MemoryStore = 0;
                lstMemoryTrail.Items.Clear();

                //Add to History
                AddToHistory("Clear", txtEquation.Text);

                return;
            }

            //Memory Recall
            if (btnPressName == "MR")
            {
                txtEquation.Text = MemoryStore.ToString();
                return;
            }

            //Memory Store
            if (btnPressName == "MS")
            {
                MemoryStore = decimal.Parse(txtEquation.Text);
                lstMemoryTrail.Items.Add(MemoryStore);
                return;
            }

            //Memory Plus
            if (btnPressName == "M+")
            {
                MemoryStore += decimal.Parse(txtEquation.Text);
                txtEquation.Text = MemoryStore.ToString();
                lstMemoryTrail.Items.Add(MemoryStore);

                //Add to History
                AddToHistory("Memory Add", txtEquation.Text);

                return;
            }

            //Memory Minus
            if (btnPressName == "M-")
            {
                MemoryStore -= decimal.Parse(txtEquation.Text);
                txtEquation.Text = MemoryStore.ToString();
                lstMemoryTrail.Items.Add(MemoryStore);

                //Add to History
                AddToHistory("Memory Minus", txtEquation.Text);

                return;
            }

            //Memory Trail
            if (btnPressName == "M")
            {
                if (lstMemoryTrail.Visible == false) 
                { 
                    lstMemoryTrail.Visible = true;
                }
                else
                {
                    lstMemoryTrail.Visible = false;
                }
                return;
            }
        }       
        private void buttonFunction_Click(object sender, EventArgs e) 
        {
            Button btnPressSel = (Button)sender;
            string btnPressName = btnPressSel.Text;

            if (btnPressName == "%")
            {
                txtEquation.Text = (val*(Double.Parse(txtEquation.Text) / 100)).ToString();
            }
            
            if (btnPressName == "1/x")
            {
                double num = Double.Parse(txtEquation.Text);
                if (num != 0.0)
                {
                    num = 1 / num;
                }
                txtEquation.Text = num.ToString();
            }
        }
        private void buttonSquareRoot_Click(object sender, EventArgs e)
        {
            txtEquation.Text = Math.Sqrt(Double.Parse(txtEquation.Text)).ToString();
            val = Math.Sqrt(Double.Parse(txtEquation.Text));
        }
        private void buttonPositiveNegative_Click(object sender, EventArgs e) 
        { 
            if (txtEquation.Text.StartsWith("-")) 
            { 
                txtEquation.Text = txtEquation.Text.Substring(1);
            }
            else if (!string.IsNullOrEmpty(txtEquation.Text) && decimal.Parse(txtEquation.Text) != 0) 
            { 
                txtEquation.Text = $"-{txtEquation.Text}";          
            }
        
        }
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {

            txtEquation.Text = "0";
            val = 0;
            lblEquation.Text = "";

            //Add to History
            AddToHistory("Clear", txtEquation.Text);
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(1);
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (txtEquation.SelectionLength > 0)
                txtEquation.Copy();
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
            { 
                txtEquation.Paste();
            }
        }
        private void importFromTextToolStripMenuItem_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text Files|*.txt";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;

                string[] lines = File.ReadAllLines(filePath);
                string[] values;

                for (int i = 0; i < lines.Length; i++)
                {
                    values = lines[i].ToString().Split(' ');
                    string[] row = new string[values.Length];

                    for (int j = 0; j < values.Length; j++)
                    {
                        row[j] = values[j].Trim();                
                    }
                    historyGridView1.Rows.Add(row);
                }
            }
        }       
        private void exportToTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Text Files|*.txt";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = File.CreateText(sfd.FileName))
                {
                    for (int i = 0; i < historyGridView1.Rows.Count - 1; i++)
                    {
                        for (int j = 0; j < historyGridView1.Columns.Count; j++)
                        {
                            sw.Write(historyGridView1.Rows[i].Cells[j].Value.ToString() + " ");
                        }
                        sw.WriteLine();
                    }
                }

            }            
        }
        private void saveToXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "XML|*.xml";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                DataTable dt = new DataTable();
                dt.TableName = "History";

                for (int i = 0; i < historyGridView1.Columns.Count; i++)
                {
                    string headerText = historyGridView1.Columns[i].HeaderText;
                    headerText = Regex.Replace(headerText, "[-/, ]", "_");

                    DataColumn column = new DataColumn(headerText);
                    dt.Columns.Add(column);
                }

                foreach (DataGridViewRow rows in historyGridView1.Rows)
                {
                    DataRow dataRow = dt.NewRow();
                    dataRow["Hist_ID"] = rows.Cells[0].Value;
                    dataRow["Hist_Action"] = rows.Cells[1].Value;
                    dataRow["Hist_Value"] = rows.Cells[2].Value;

                    dt.Rows.Add(dataRow); 
                }
                DataSet ds = new DataSet();
                ds.Tables.Add(dt);

                XmlTextWriter xmlSave = new XmlTextWriter(sfd.FileName, Encoding.UTF8);
                xmlSave.Formatting = Formatting.Indented;
                ds.DataSetName = "Data";
                ds.WriteXml(xmlSave);
                xmlSave.Close();
            }       
        }
        private void AddToHistory(string action, string value)
        {
            
            int rowIndex = 0;
            foreach (DataGridViewRow row in historyGridView1.Rows)
            {
                rowIndex += 1;
            }

            int rows = historyGridView1.Rows.Add();
            historyGridView1[0, rows].Value = rowIndex.ToString();
            historyGridView1[1, rows].Value = action; 
            historyGridView1[2, rows].Value = value;
        }      
    }
}