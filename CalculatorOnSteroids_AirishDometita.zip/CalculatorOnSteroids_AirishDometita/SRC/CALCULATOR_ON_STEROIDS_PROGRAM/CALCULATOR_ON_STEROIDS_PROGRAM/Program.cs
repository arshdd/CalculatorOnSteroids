using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CALCULATOR_ON_STEROIDS_PROGRAM
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new frmCalculator());
        }
    }
}